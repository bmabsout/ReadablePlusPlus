
public class TokenPair {
	public final int token;
	public final String lexeme;
	
	
	public TokenPair(int token, String lexeme){
		this.token = token;
		this.lexeme = lexeme;
	}
}
